ALTER TABLE complains ADD COLUMN complain_hash varchar(255);
